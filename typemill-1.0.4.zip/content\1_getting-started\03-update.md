# Update

If your version of TYPEMILL is not up to date, you will find an update notice in your footer. 

To update your TYPEMILL version, simply download the latest version of TYPEMILL on ![the TYPEMILL website](http://typemill.net). Then delete the old `system` folder on your server and upload the new system folder. Sometimes it is a good idea to delete the content in the cache folder too. 