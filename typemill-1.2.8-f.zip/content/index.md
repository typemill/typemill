# Typemill

**MODERN WEB PUBLISHING FOR WRITERS**

*Typemill is a user-friendly and lightweight open source CMS for publishing text-works like prosa, lyrics, manuals, documentations, studies and more. Just download and start.*

