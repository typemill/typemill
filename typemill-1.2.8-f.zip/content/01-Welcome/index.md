# Welcome to Typemill

Great that you give Typemill a try!! Typemill is a small open source cms and a project in work. You will probably miss some important features, but I am working hard to add everything that is needed for a handy and productive writing-system.

Read the short introduction about "writing content" before you start or simply play around and try it out.

