# Get Help

If you need any help, then please read the [documentation on typemill.net](https://typemill.net/typemill) first. Some short video-tutorials are in work right now.

If you found a bug or if you have a question, then please open a new issue on [GitHub](https://github.com/trendschau/typemill/issues).

Typemill is open source and a one man project right now, so please understand that I cannot provide individual support.

Contributions, donations and feedbacks are always welcome.

