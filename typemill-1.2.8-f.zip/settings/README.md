Settings are generated during the setup of the system.

If you are a developer, you can manually add the settings

````
displayErrorDetails: true
````

This will display the php errors during the developement process. Do not forget to disable the settings for the live environment (delete it or set it to false).

