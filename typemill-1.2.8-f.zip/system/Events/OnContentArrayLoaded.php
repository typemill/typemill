<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for the page rendering data.
 */

class OnContentArrayLoaded extends BaseEvent
{

}