# Info

Some informations like version history, copyright, licence and imprint.