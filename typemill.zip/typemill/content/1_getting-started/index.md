# Getting Started

Simply download TYPEMILL and immediately start publishing. TYPEMILL runs with **php5.6+** on most webservers. **No database** or any other additional technology is required.