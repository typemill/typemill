#About TYPEMILL

TYPEMILL is a simple tool to create a website like this. It transforms a bunch of **text files** (Markdown) into a **website** and generates a **navigation**. TYPEMILL is a perfect tool for web books, documentations or manuals.