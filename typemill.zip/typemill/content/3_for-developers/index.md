# Hello Developers!

If you love **lightweight systems**, stupid **simple theming** and the template language **Twig**, then TYPEMILL is for you!