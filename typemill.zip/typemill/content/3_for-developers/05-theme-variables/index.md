# Theme Variables

TYPEMILL provides **six variables** for your theme. They are easy to understand and simple to use.  