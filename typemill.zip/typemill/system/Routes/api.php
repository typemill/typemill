<?php
/*
use App\Controllers\ApiController;

$app->get('/api', ApiController::class . ':index' )->setName('api.index');
*/
?>