<?php

namespace Typemill\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Event for settings
 */
 
class OnSettingsLoaded extends BaseEvent
{

}