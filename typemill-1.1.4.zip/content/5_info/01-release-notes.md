#Release Notes

This is the version history with some release notes.

## Version 1.1.4 (30.04.2018)

**Please follow the instructions for minor updates** in the [documentation](/gettings-started/update). Please update the Typemill theme, too.

Version 1.1.4 is mainly an optimization and refactoring of the author panel released in version 1.1.3. Some details of the changes:

* Length of description is optimized for SEO now.
* You can display a last modified date on each page now (update the TYPEMILL theme for that).
* Optimized mobile version of the author-panel navigation.
* Form rendering is now done in a seperate form template.
* SettingsController is deeply refactored and some bugs are fixed.
* FormModel partly fixed and refactored.
* ValidationModel fixed.
* Update notifications for system, themes and plugins are completely refactored and unified.
* Welcome page is fixed, so that the linked themes- and plugin settings show the initial values now.
* Settings functions for plugins and themes are cleaned up and unified.
* Design is partly fixed and unified (open-close icons and more).
* User documentation has been enhanced and corrected.

## Version 1.1.3 (19.04.2018)

**Please follow the instructions for major updates** in the [documentation](/gettings-started/update).

Version 1.1.3 introduces an author panel. Now you can authenticate, configure the system, themes and plugins and manage users. This is the first step towards a full authoring panel that helps you to manage, create and edit everything online.

* Author panel.
* Authentication.
* Configuration of the system, the theme and the plugins.
* User management (create update and deleted).
* Bugfix: Footnotes in Markdown didn't work due to parsedown library. Fixed in the new library version.

## Version 1.1.2 (15.03.2018)

With version 1.1.2 we added the possibility to configure the theme in the setup a bit more. We also fixed a bug in the htaccess. So next to the "system"-folder, you should also update the theme-folder and the htaccess-file. As always, backup your settings.yaml-file, then delete it and setup your website again (visit /setup).

* Added configurations for themes in the setup.
* Improved update check for themes, plugins and base app.
* optimized design of setup.
* Added language selection to setup (used only for lang-attribute right now).
* Updated typemill theme accordingly
* Bugfix: Index.php is not reachable anymore, prevents duplicate content. Please update htaccess-file. 

## Version 1.1.1 (25.02.2018)

* Added new plugin "analytics" for integration of Matomo/Piwik and Google Analytics.
* Theme "TYPEMILL": Design refresh.
* Theme "TYPEMILL": Added cannonical url.
* Theme "TYPEMILL": Added meta tags for social sharing including image reference.
* Increased length of meta-description for google.
* Fixed error with field builder (getAttributeValues).
* Fixed error with static functions in settings (added declaration as static).
* Added documentation for plugin developers.

## Version 1.1.0 (05.02.2018)

Version 1.1.0 introduces plugins to typemill. And because of the GDPR, the first plugin is an implementation of the famous cookieconsent. So heads up, you can publish GDPR-compliant websites with typemill now! 

All plugins are in the "plugin"-folder, and I can't wait, that this folder will be stuffed with cool extensions.

To update the system, please delete, replace and upload

* the "system" folder and
* the "theme" folder.
* the "plugin" folder (new).

Then backup and delete your settings.yaml in the settings-folder. 

Now visit your startpage and click on the new setup-button. The button will direct you to the new setup page, where you can configure the basic system and the new cookieconsent-plugin.

Plugins are easy to use for writers, but a plugin system is pretty complex to implement for a developer, so there is a lot of new code. For now, there is no documentation for developers, but it will follow, soon.

Also introduced with 1.1.0 :

* Field Builder
* CSRF-Protection
* Input Validation
* Version Check for Plugins, Themes and Core-System
* Simple Asset Manager
* Twig Extensions

## Version 1.0.5 (30.11.2017)

- Improvement: Character encoding for the navigation has improved. You can try to use other characters than english for your file names now, but there is no garanty for it. If the characters do not work in the navigation, please use english characters only.
- Improvement: A [TOC]-tag for generating a table of contents is now implemented. You can use the tag anywhere in your text-files, but please use a separate line for it. Update the theme for stylings.

## Version 1.0.4 (17.11.2017)

- Bugfix: Settings file was generated after a page refresh, this is fixed now.
- Improvement: Cleaned up the load and merge process for settings, managed in a new static class now.

## Version 1.0.3 (14.11.2017)

- Bugfix: Deleted a config-file in the download-version, that broke the setup url.
- Improvement: Meta-title is now created with the first h1-headline in the content file. File-name is used as fall back. **Please update the theme-folder with the theme-folder of version 1.0.3!!!** This will improve SEO.
- Improvement: Stripped out all developer files in the download-version. This reduced the size of the zip-download from 2.5 MB to 800kb.
- Improvement: Changed Namespace from "System" to "Typemill".

## Version 1.0.2 (02.07.2017)

- Bugfix: The theme can now be changed in the yaml-file again.

## Version 1.0.1 (01.05.2017)

- Bugfix: Index file in the content folder won't break the building of the navigation tree anymore. 
- New Feature: Added a google sitemap.xml in the cache folder.
- New Feature: Added a version check, an update message can be displayed in theme now.

## Version 1.0.0 (13.04.2017)
The first alpha version of typemill with all basic features for a simple website:

- **Content** with Markdown files and folders
- **Settings** with YAML and a setup page
- **Themes** with Twig and six theme variables
  - {{ content }}
  - {{ description }}
  - {{ item }}
  - {{ breadcrumb }}
  - {{ navigation }}
  - {{ settings }}