# Übermaß: A simple encoding test

This is just a test for character encoding. If you see the correct german word "Übermaß" in the left navigation, and if you can click the navigation link to get to this page, then everything works fine. 

I still encourage you to use only english characters to name your content files, because many special characters and many languages won't work. I even doubt, that german or european characters will work in special server environments. So you can try it, but if it does not work, you only option is to avoid special characters in your file-names.