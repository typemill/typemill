# Hello Plugin-Developers!

You can extend TYPEMILL with your own **plugins**. Simply use the **event-system** based on the symfony event dispatcher and configure an user-interface with a super simple **YAML-file**.