# Documentation

If you are already familiar with plugin development or if you want to refresh your knowledge, than check the documentation. Find a list of **events** fired by TYPEMILL, learn about useful **helper methods**, check the comprehensive list of **field definitions** or learn how to add your own **routes** and your own **middleware**. 