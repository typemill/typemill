# Themes

TYPEMILL ships with the standard theme called "Typemill". Typemill is a univeral theme the fits for documentations as well as for any other kind of text-work. There are plans to add a lot more themes for specific need s in the future.

You can configure the theme in the settings of the author panel. You will see an update banner, if there is a new version of the theme available.

To update a theme, simply go to the theme folder of your typemill installation, delete the old folder of your theme (e.g. `/typemill`) and upload the new folder.

If you are a developer or web-designer, you can easily create your own theme with the template language Twig. Please read the [theme documentation](/theme-developers) for more details.