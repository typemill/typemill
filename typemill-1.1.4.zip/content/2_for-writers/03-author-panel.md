# The Author Panel

After you have setup your TYPEMILL website, you can login to the author panel. The login url is 

````
https://yourwebsite.net/tm-author/login
````

You can also use the url `https://yourwebsite.net/setup` that redirects to the login screen.

In the **settings area** of the author panel you can:

* Configure your **system**.
* Choose and configure a **theme**.
* Activate and configure **plugins**.
* Manage **users**.

the **content area** of the author-panel is not ready yet, but it is on it's way and will be published in near future. Then you can create and manage all the content of your website online. For time being you have to create your content offline e.g. with a markdown editor and upload your content files with a FTP software.