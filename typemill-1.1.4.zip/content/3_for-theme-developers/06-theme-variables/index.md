# Theme Variables

TYPEMILL provides **9 variables** for your theme right now. They are easy to understand and simple to use.  