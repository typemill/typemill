# System Requirements

TYPEMILL is a modern and lightweight software with nearly no requirements. All you need is:

- **A webserver** (to host TYPEMILL)
- **PHP 5.6+** (to run TYPEMILL)
- **FTP** (to upload your content files)

What you don't need:

- **A lot of space** (TYPEMILL is  lightweight with less than 5MBs)
- **A database** (TYPEMILL uses files, not a database)
- **Technical skills** (TYPEMILL is easy to use for non-technical people)

Almost any hosting package provides a webserver with php. If you ever hosted a website with WordPress, then chances are high, that you can run TYPEMILL there without any problems.