# Folder Structure

You can create any kind of folder structer with TYPEMILL. As long as you follow the naming conventions for folders and files, it will work.

However, if you create a very deep structure, then it might result in an odd design or even in usability errors. Similar to real live, it is always a good idea to keep the hierarchy as flat as possible.