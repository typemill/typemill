# Description

The description variable extracts the first 150 characters of the content. You can print the description out with:

    {{ description }}

You can use the description for the meta-tag in your HTML head, for example.


